# 사용자 인증 정보
users = {}

# 학생 정보 
students = {}

# 교수 정보 
professors = {}

# 관리자 정보 
admins = {}

# 강의 정보 
courses = {}

# 성적 정보 
grades = {}

# 출결 정보 
attendance = {}

# 공지사항 목록 
notices = []

# 졸업 요건 정보 
graduation_requirements = {}

# 학적 변동 신청 목록 
academic_requests = []